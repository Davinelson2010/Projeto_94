function mudarTema () {
 document.getElementById("body").style.backgroundColor =  "white";
}   